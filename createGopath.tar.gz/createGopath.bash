#!/bin/bash

gopath="$HOME/gopath"

if [ -d $gopath ]; then
  echo "$gopath already exist"
  exit 1
fi

echo "creating GOPATH: $gopath"
mkdir $HOME/gopath

export GOPATH=$gopath

echo "download and install package: goimports"
go get -u golang.org/x/tools/cmd/goimports

echo "download and install package: cmd"
go get -u golang.org/x/tools/cmd/...

echo "download and install package: golint"
go get -u github.com/golang/lint/golint

echo "adding gopath to bash_profile"
echo "export GOPATH=$gopath" >> ~/.bash_profile

echo "adding gopath/bin to bash_profile"
echo 'export PATH=$PATH:'"$gopath/bin">> ~/.bash_profile
echo
echo "***********************************************"
echo "**         Installation is successful        **"
echo "**         run in a terminal                 **"
echo "**         source ~/.bash_profile            **"
echo "***********************************************"










